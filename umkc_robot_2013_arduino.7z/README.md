umkc_robot_2013_arduino
=======================

This is the Arduino code for the UMKC Robotics Team for the 2013 IEEE R5 
competition.

Flash this to the Arduino using the Arduino IDE version 0023. (NOT any 
version above 1.0)

Include the ros_lib directory in Arduino's libraries, either in it's own 
directory\libraries, or under your Documents\Arduino\libraries

Wiring diagram included in PDF and FZZ (Fritzing) format. Frizing is available
by going to www.fritzing.org.
